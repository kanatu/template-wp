<?php get_header(); ?>
            <!-- single-->
            <div id="main">
                <div id="content">
                    <div id="destaques">
                        <div><img src="<?php bloginfo('template_url'); ?>/img/materia-1.png" /></div>
                        <div><img src="<?php bloginfo('template_url'); ?>/img/materia-2.png" /></div>
                        <div><img src="<?php bloginfo('template_url'); ?>/img/publicidade.png" /></div>
                        <div><img src="<?php bloginfo('template_url'); ?>/img/materia-3.png" /></div>
                        <div><img src="<?php bloginfo('template_url'); ?>/img/materia-4.png" /></div>
                    </div>

                    <div id="materias">
                        <div><img src="<?php bloginfo('template_url'); ?>/img/materia-5.png" /></div>
                        <div><img src="<?php bloginfo('template_url'); ?>/img/materia-6.png" /></div>
                        <div><img src="<?php bloginfo('template_url'); ?>/img/materia-7.png" /></div>
                        <div><img src="<?php bloginfo('template_url'); ?>/img/materia-8.png" /></div>
                    </div>
                </div>
            </div><!-- #main -->
            <!-- single-->
<?php get_footer(); ?>